<?php
require 'gapi.class.php';
define('ga_profile_id','171744989');

$ga = new gapi("analyticsservice@analyticsservice-198217.iam.gserviceaccount.com", "key.p12");

/**
 * Note: OR || operators are calculated first, before AND &&.
 * There are no brackets () for precedence and no quotes are
 * required around parameters.
 * 
 * Do not use brackets () for precedence, these are only valid for 
 * use in regular expressions operators!
 * 
 * The below filter represented in normal PHP logic would be:
 * country == 'United States' && ( browser == 'Firefox || browser == 'Chrome')
 */

// $filter = 'country == Brazil && browser == Firefox || browser == Chrome';
$filter = '';

$ga->requestReportData(ga_profile_id,array('browser','browserVersion'),array('pageviews','visits'),'-visits',$filter);
?>
<table>
<tr>
  <th>Navegador &amp; Versao</th>
  <th>Paginas Vistas</th>
  <th>Visitas</th>
</tr>
<?php
foreach($ga->getResults() as $result):
?>
<tr>
  <td><?php echo $result ?></td>
  <td><?php echo $result->getPageviews() ?></td>
  <td><?php echo $result->getVisits() ?></td>
</tr>
<?php
endforeach
?>
</table>

<table>
<tr>
  <th>Total Resultados</th>
  <td><?php echo $ga->getTotalResults() ?></td>
</tr>
<tr>
  <th>Total Paginas Vistas</th>
  <td><?php echo $ga->getPageviews() ?>
</tr>
<tr>
  <th>Total Visitas</th>
  <td><?php echo $ga->getVisits() ?></td>
</tr>
<tr>
  <th>Faixa de data de resultado</th>
  <td><?php echo $ga->getStartDate() ?> to <?php echo $ga->getEndDate() ?></td>
</tr>
<tr>
  <th>Paginas acessadas e Numero de visitas</th>
  <td><?php echo json_encode($ga->getMetrics()); ?></td>
</tr>
</table>