<?php
require 'gapi.class.php';

$ga = new gapi("analyticsservice@analyticsservice-198217.iam.gserviceaccount.com", "key.p12");

$ga->requestAccountData();

foreach($ga->getAccounts() as $result)
{
  echo $result . ' ' . $result->getId() . ' (' . $result->getProfileId() . ")<br />";
}
